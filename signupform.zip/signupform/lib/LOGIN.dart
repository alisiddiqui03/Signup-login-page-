import 'dart:html';

import 'package:flutter/material.dart';

class  App extends StatefulWidget {
const App({ Key? key }) : super(key: key);

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  get nameController => null;
    get passwordController => null;
@override
      Widget build(BuildContext context) {
      return Scaffold(
      backgroundColor: Colors.black,
      body: 
       new Column(
      children: <Widget>[
   new Container(
          padding: new EdgeInsets.only(top: 50.0),
          margin: EdgeInsets.only(left: 20),
          child: new Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              new Text(
                "LET'S SIGN YOU UP ",
                style: new TextStyle(
                  fontSize: 45.0,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  color: Colors.white
                ),
              )
            ],
          ),
        ),
        new Container(
          padding: new EdgeInsets.only(top: 16.0),
          margin: EdgeInsets.only(left: 20),
          child: new Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            
            children: <Widget>[
              new Text(
                "WELCLOME",
                style: new TextStyle(
                  fontSize: 35.0,
                  fontFamily: 'Roboto',
                  color: Colors.white
                ),
              )
            ],
          ),
        ),
          new Container(
          padding: new EdgeInsets.only(top: 16.0),
          margin: EdgeInsets.only(left: 20),
          child: new Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            
            children: <Widget>[
              new Text(
                "Join The Community! ",
                style: new TextStyle(
                  fontSize: 35.0,
                  fontFamily: 'Roboto',
                  color: Colors.white
                ),
              )
            ],
          ),
        ),
        SizedBox(height: 30),
         Container(
        color: Colors.white60,
        margin: EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
        child: TextField(   
        controller: nameController,
        decoration:  InputDecoration(
        border: OutlineInputBorder(),
        labelText: 'User Name',
            fillColor: Colors.white,
          focusedBorder:OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 2.0),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ),
          
        ),
        ),
          Container(
        color: Colors.white60,
        margin: EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
        child: TextField(   
        controller: nameController,
        decoration:  InputDecoration(
        border: OutlineInputBorder(),
        labelText: 'E-MAIL',
            fillColor: Colors.white,
          focusedBorder:OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 2.0),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ),
          
        ),
             ), 
               Container(
        color: Colors.white60,
        margin: EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
        child: TextField(   
          obscureText: true,
        controller: passwordController,
        decoration:  InputDecoration(
        border: OutlineInputBorder(),
        labelText: 'Password',
            fillColor: Colors.white,
          focusedBorder:OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 2.0),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ),
          
        ),
        ),

         MaterialButton
                (height:40,
                     onPressed: (){
                       Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => MyApp()),
  );  
                      },
                      
                      color: Colors.grey,
                      shape: RoundedRectangleBorder(
                        
                          borderRadius: BorderRadius.circular(40)
                      ),
                      
                      child: Text("Sign UP",style: TextStyle(
                        fontWeight: FontWeight.w600,fontSize: 26,

                      ),),
                    ),	   
                    SizedBox(height: 5),
                     Container(
                       
                       alignment: Alignment.center,
                  child:
            Text('Already have an account?',style: TextStyle(color: Colors.grey,  ),textAlign: TextAlign.center,),
                     )
      ],
            ),
                  
                     
                      
    
    );
  }
}
class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}
class _MyAppState extends State<MyApp> {
  TextEditingController EmailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.black,
      body: 
       new Column(
      children: <Widget>[
   new Container(
          padding: new EdgeInsets.only(top: 50.0),
          margin: EdgeInsets.only(left: 20),
          child: new Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              new Text(
                "LET'S SIGN YOU IN ",
                style: new TextStyle(
                  fontSize: 45.0,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  color: Colors.white
                ),
              )
            ],
          ),
        ),
        new Container(
          padding: new EdgeInsets.only(top: 16.0),
          margin: EdgeInsets.only(left: 20),
          child: new Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            
            children: <Widget>[
              new Text(
                "WELCLOME BACK",
                style: new TextStyle(
                  fontSize: 35.0,
                  fontFamily: 'Roboto',
                  color: Colors.white
                ),
              )
            ],
          ),
        ),
          new Container(
          padding: new EdgeInsets.only(top: 16.0),
          margin: EdgeInsets.only(left: 20),
          child: new Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            
            children: <Widget>[
              new Text(
                "YOU HAVE BEEN MISSED! ",
                style: new TextStyle(
                  fontSize: 35.0,
                  fontFamily: 'Roboto',
                  color: Colors.white
                ),
              )
            ],
          ),
        ),
        SizedBox(height: 30),
         Container(
        color: Colors.white60,
        margin: EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
        child: TextField(   
        controller: EmailController,
        decoration:  InputDecoration(
        border: OutlineInputBorder(),
        labelText: 'User Name',
            fillColor: Colors.white,
          focusedBorder:OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 2.0),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ),
          
        ),
        ),
          Container(
        color: Colors.white60,
        margin: EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
        child: TextField(   
        controller: passwordController,
        decoration:  InputDecoration(
        border: OutlineInputBorder(),
        labelText: 'E-MAIL',
            fillColor: Colors.white,
          focusedBorder:OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 2.0),
            borderRadius: BorderRadius.circular(25.0),
      ),
                  ),
      
          ),
          ), MaterialButton
                (height:40,
                     onPressed: (){
                       Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => page1()),
  );  
                      },
                      
                      color: Colors.grey,
                      shape: RoundedRectangleBorder(
                        
                          borderRadius: BorderRadius.circular(40)
                      ),
                      
                      child: Text("SIGN IN",style: TextStyle(
                        fontWeight: FontWeight.w600,fontSize: 36,

                      ),),
                    ),	   
                    SizedBox(height: 15),
                     Container(
                       
                       alignment: Alignment.center,
                  child:
            Text('Dont have an account?',style: TextStyle(color: Colors.grey,fontSize: 25  ),textAlign: TextAlign.center,),
                     )
      ],
          
       )
    );
  }
  }
class page1 extends StatefulWidget {
  page1({ Key? key }) : super(key: key);
  
  @override
  State<page1> createState() => _page1State();
}

class _page1State extends State<page1> {
   TextEditingController nameController = TextEditingController();
  TextEditingController paragraphController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
  backgroundColor: Colors.black,
      body: 
       new Column(
      children: <Widget>[
   new Container(
          padding: new EdgeInsets.only(top: 20.0),
          margin: EdgeInsets.only(right: 50),
          child: new Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              IconButton(
    onPressed: () {
       Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => MyApp()),
       );
    },
    icon: Icon(Icons.arrow_back,color: Colors.white,size: 45.0),
              ),
              
            
               
                  SizedBox(width: 50),
              new Text(
                "ADD NEW JOB ",
                style: new TextStyle(
                  fontSize: 45.0,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  color: Colors.white
                ),
              )
            ],
          ),
        ), 
        SizedBox(height: 30),
         Container(
        color: Colors.white60,
        margin: EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
        child: TextField(   
        controller: nameController,
        decoration:  InputDecoration(
        border: OutlineInputBorder(),
        labelText: 'ADD YOUR SKILLS',
            fillColor: Colors.white,
          focusedBorder:OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 2.0),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ),
        ),
        ),
 SizedBox(height: 30),
         Container(
        
        color: Colors.white60,
        margin: EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
        child: TextField(   
          style:TextStyle( 
        height: 15.0),
        controller: paragraphController,
        decoration:  InputDecoration(
        border: OutlineInputBorder(),
        labelText: 'DETAILS OF YOUR COURSE',
         contentPadding: EdgeInsets.all(20.0),
            fillColor: Colors.white,
          focusedBorder:OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 2.0),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ),
        ),
        ),
          MaterialButton
                (height:40,
                     onPressed: (){
                       Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => page2()),
  );  
                      },
                      
                      color: Colors.grey,
                      shape: RoundedRectangleBorder(
                        
                          borderRadius: BorderRadius.circular(40)
                      ),
                      
                      child: Text("Submit Job",style: TextStyle(
                        fontWeight: FontWeight.w600,fontSize: 26,

                      ),),
                    ),	   
       ])     
    );
  }
}
class page2 extends StatefulWidget {
  const page2({ Key? key }) : super(key: key);

  @override
  State<page2> createState() => _page2State();
}

class _page2State extends State<page2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
  backgroundColor: Colors.black,
      body: 
       new Column(
      children: <Widget>[
   new Container(
          padding: new EdgeInsets.only(top: 20.0),
          margin: EdgeInsets.only(right: 50),
          child: new Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              IconButton(
    onPressed: () {
       Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => page1()),
       );
    },
    icon: Icon(Icons.arrow_back,color: Colors.white,size: 45.0),
              ),
              
            
               
                  SizedBox(width: 50),
              new Text(
                "EDIT JOB ",
                style: new TextStyle(
                  fontSize: 45.0,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  color: Colors.white
                ),
              )
            ],
          ),
        ), 
        SizedBox(height: 30),
         Container(
        margin: EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
   width: double.infinity,
  decoration: BoxDecoration(
     shape: BoxShape.rectangle,
    border: Border.all(
      color: Colors.grey,
      width: 2.0
    ),
    borderRadius: BorderRadius.circular(10.0),
  ),
  child: Text("Flutter Developer",style: TextStyle(color: Colors.grey,fontSize: 18),),
        ),
        SizedBox(height: 5.0),
         Container(
           margin: EdgeInsets.all(10),
         height:300,
  width: double.infinity,
  decoration: BoxDecoration(
     shape: BoxShape.rectangle,
    border: Border.all(
      color: Colors.grey,
      width: 2.0
    ),
    borderRadius: BorderRadius.circular(10.0),
  ),
  
    child: Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum",style: TextStyle(color: Colors.grey,fontSize: 28,fontWeight: FontWeight.w100),
    textDirection: TextDirection.ltr,),
  ),    
        
        SizedBox(height: 20),
          MaterialButton
                (height:40,
                     onPressed: (){
                       Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => page3()),
  );  
                      },
                      
                      color: Colors.grey,
                      shape: RoundedRectangleBorder(
                        
                          borderRadius: BorderRadius.circular(40)
                      ),
                      
                      child: Text("Update Job",style: TextStyle(
                        fontWeight: FontWeight.w600,fontSize: 26,

                      ),),
                    ),
      ]
       )      
      
    );
  }
}
class page3 extends StatefulWidget {
  const page3({ Key? key }) : super(key: key);

  @override
  State<page3> createState() => _page3State();
}

class _page3State extends State<page3> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
       body: 
        Column(
      children: <Widget>[
  Container(
          margin: EdgeInsets.only(left: 10),
          child:  Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Text(
                "WELCOME",
                style: new TextStyle(
                  fontSize: 45.0,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  color: Colors.white
                ),   
              ),
             
               IconButton(
       alignment: Alignment.topLeft,           
    onPressed: () {
       Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => MyApp()),
       );
    },
    icon: Icon(Icons.arrow_back_ios_new_rounded,color: Colors.white,size: 45.0),
              ),
              
      
      ],
      
          ),
        ),
        new Container(
          padding: new EdgeInsets.all(10),
          child: new Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            
            children: <Widget>[
              new Text(
                "M ALI SIDDIQUI",
                style: new TextStyle(
                  fontSize: 30.0,
                  fontWeight:FontWeight.normal,
                  fontFamily: 'Roboto',
                  color: Colors.white
                ),
              )
            ],
          ),
        ),
          SizedBox(height: 30),
         Container(
        margin: EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
   width: double.infinity,
  decoration: BoxDecoration(
     shape: BoxShape.rectangle,
    border: Border.all(
      color: Colors.grey,
      width: 2.0
    ),
    borderRadius: BorderRadius.circular(10.0),
  ),
   
  
  child: Text( "Flutter Developer",style: TextStyle(color: Colors.grey,fontSize: 20),textAlign: TextAlign.justify),
        ),
 abc('FLUTTER DEVELEOPER REQUIRED', 'providing benefits', Colors.grey),
 abc('FLUTTER DEVELEOPER REQUIRED', 'providing benefits', Colors.grey), 
 abc('FLUTTER DEVELEOPER REQUIRED', 'providing benefits',Colors.grey), 
abc('FLUTTER DEVELEOPER REQUIRED', 'providing benefits',Colors.grey), 


      ]
    )
    );
  }
 Widget abc(String name,String msg,Color color)
{
return Container(
        margin: EdgeInsets.all(10),
   width: double.infinity,
  decoration: BoxDecoration(
     shape: BoxShape.rectangle,
    border: Border.all(
      color: Colors.grey,
      width: 2.0
    ),
    borderRadius: BorderRadius.circular(5.0),
  ),
  child:
ListTile(
          title: Text(name,style: TextStyle(color: Colors.white),),
          subtitle: Text(msg,style: TextStyle(color: Colors.grey)),
          trailing: Wrap(
    spacing: 12, // space between two icons
    children: <Widget>[
      Icon(Icons.note_add),// icon-1
      Icon(Icons.delete_outlined,color: Colors.orange,), // icon-2
    ],
  ),        
),
     
);
}
}