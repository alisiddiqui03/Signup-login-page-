import 'package:flutter/material.dart';
import 'LOGIN.dart';
void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: App(),
  ));
}


